# groups/core/__init__.py

from .group import group

__all__ = ["group"]
