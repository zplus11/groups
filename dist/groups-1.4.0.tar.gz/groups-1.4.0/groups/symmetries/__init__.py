# groups\symmetries\__init__.py

from .dihedral import dihedral

__all__ = ["dihedral"]
