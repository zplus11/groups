from itertools import combinations
from functools import lru_cache

class group:
    def __init__(self, identity: None):
        self.members = []
        self.elements = []
        self.identity = identity

    def determine(self, current_state):
        result = None
        for element in self.elements:
            if self.elements[element] == current_state:
                result = element
                break
        return result

    @lru_cache(maxsize = None)
    def subgroups(self, order: int = None):
        assert order is None or type(order) == int, f"Invalid order {order}"
        if type(order) == int: assert 1 <= order <= len(self.members), f"Invalid order {order}"
        subgroups = []
        if order is None:
            sublists_to_check = filter(lambda sublist: 1 <= len(sublist) <= int(len(self.members)/2) or sublist == self.members, self.__generate_sublists())
        elif len(self.members) % order == 0:
            sublists_to_check = filter(lambda sublist: len(sublist) == order, self.__generate_sublists())
        else:
            sublists_to_check = []
        for sublist in sublists_to_check:
            if len(self.members) % len(sublist) == 0:
                if self.check_subgroup(sublist):
                    subgroups.append(sublist)
        return subgroups
    
    def check_subgroup(self, subset: list):
        if self.identity not in subset:
            return False
        elif any(i not in self.members for i in subset):
            return False
        elif any(self.determine(self.apply(i, j)) not in subset for i in subset for j in subset):
            return False
        else:
            return True

    def __generate_sublists(self):
        sublists = [list(c) for r in range(len(self.members) + 1) for c in combinations(self.members, r)]
        return sublists
