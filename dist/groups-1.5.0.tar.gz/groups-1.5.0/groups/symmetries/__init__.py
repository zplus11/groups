# groups\symmetries\__init__.py

from .dihedral import Dihedral

__all__ = ["Dihedral"]
